Apply from the server vllm-ascend checkout after the additional_config migration.
This patch only improves diagnostics; runtime restrictions stay unchanged.

git apply --check /path/to/dflash_feedback_diagnostics.patch
git apply /path/to/dflash_feedback_diagnostics.patch

If the check fails, do not overwrite local customizations: inspect the differences.
